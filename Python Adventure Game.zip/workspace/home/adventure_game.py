import time
import random

# Random monster names
MONSTERS = ["ghoul", "troll", "pirate", "anaconda"]

# Functions
def print_pause(*messages):
    """Print messages with a pause between each."""
    for message in messages:
        print(message)
        time.sleep(2)

def get_random_monster():
    """Return a random monster from the list."""
    return random.choice(MONSTERS)

def get_choice():
    """Prompt the user to enter 1 or 2 and return the choice."""
    while True:
        try:
            choice = int(input("Please enter 1 or 2: "))
            if choice in [1, 2]:
                return choice
            else:
                print_pause("Please enter 1 or 2.")
        except ValueError:
            print_pause("Please enter 1 or 2.")

def fight_or_run(monster_name):
    """Prompt the user to choose to fight or run and return the choice."""
    while True:
        try:
            choice = int(input(f"Press 1 to fight the {monster_name} or press 2 to run: "))
            if choice in [1, 2]:
                return choice
            else:
                print_pause("Invalid input.")
        except ValueError:
            print_pause("Please enter 1 or 2.")

def play_again():
    """Prompt the user to play again and return True if 'y', otherwise False."""
    while True:
        choice = input("Do you want to play again? (y/n): ").lower()
        if choice in ['y', 'n']:
            return choice == 'y'
        else:
            print_pause("Please enter 'y' or 'n'.")

# Story Functions
def lore0(entered_cave, current_monster_name):
    """Print the initial story and choices."""
    if not entered_cave:
        print_pause("You find yourself standing in an open field, filled with grass and yellow wildflowers.")
        print_pause(f"Rumor has it that a {current_monster_name} is somewhere around here and has been terrifying the nearby village.")
        print_pause("In front of you is a house, and you were informed that this house contains a fairy.")
        print_pause("To your right is a dark cave. Rumors say that this cave has a legendary weapon.")
        print_pause("You need a magic wand value of 10 to defeat the monster.")

def lore1(magic_wand):
    """Print the story for entering the house."""
    print_pause("You have entered the house.")
    if magic_wand > 0:
        print_pause("You feel prepared and ready to face the monster.")
    else:
        print_pause("You don't feel confident fighting that monster.")
    print_pause("You knock on the door.")
    print_pause("The house contains a monster.")
    print_pause("The monster saw you.")
    print_pause("The monster runs after you.")

def lore3(cave_entries, magic_wand):
    """Print the story for entering the cave and adjust the magic wand based on entries."""
    if cave_entries % 2 == 1:
        print_pause("You have entered the cave and found a GOOD MAGIC WAND THAT DISAPPEARED 3000 YEARS AGO.")
        print_pause("You exchange it for the one you already have.")
        print_pause("You leave the cave with the magic wand.")
        return magic_wand + 10
    else:
        print_pause("You have entered the cave again, but the magic wand disappears as soon as you enter.")
        print_pause("You leave the cave with no weapon.")
        return magic_wand - 10

# Main Game Loop
def main():
    """Run the main game loop."""
    while True:
        magic_wand = 0
        cave_entries = 0
        entered_cave = False
        current_monster_name = get_random_monster()

        while True:
            lore0(entered_cave, current_monster_name)
            choice = get_choice()

            if choice == 1:
                lore1(magic_wand)
                if magic_wand > 0:
                    print_pause(f"You feel confident fighting that {current_monster_name}.")
                else:
                    print_pause(f"You don't feel confident fighting that {current_monster_name}.")
                action = fight_or_run(current_monster_name)
                if action == 1:
                    print_pause(f"You chose to fight the {current_monster_name}.")
                    if magic_wand > 0:
                        print_pause(f"You killed the {current_monster_name}. Congratulations!")
                        break
                    else:
                        print_pause(f"The {current_monster_name} killed you. Game over.")
                        break
                elif action == 2:
                    print_pause("You chose to run away!")
                    print_pause("You came back to the starting point.")
            elif choice == 2:
                cave_entries += 1
                magic_wand = lore3(cave_entries, magic_wand)
                print_pause(f"Current magic wand value: {magic_wand}")  # Print magic_wand after each cave entry
                entered_cave = True

        if not play_again():
            print_pause("Thank you for playing! Goodbye.")
            break

if __name__ == "__main__":
    main()
