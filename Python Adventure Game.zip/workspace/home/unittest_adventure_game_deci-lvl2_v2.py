import time
import random

# random monster names
MONSTERS = ["ghoul", "troll", "pirate", "anaconda"]

# Functions
def print_pause(*messages):
    """Print messages with a pause between each."""
    for message in messages:
        print(message)
        time.sleep(2)

def get_random_monster():
    """Return a random monster from the list."""
    return random.choice(MONSTERS)

def get_choice():
    """Prompt the user to enter 1 or 2 and return the choice."""
    while True:
        try:
            choice = int(input("Please enter 1 or 2: "))
            if choice in [1, 2]:
                return choice
            else:
                print_pause("Please enter 1 or 2.")
        except ValueError:
            print_pause("Please enter 1 or 2.")

def fight_or_run():
    """Prompt the user to choose to fight or run and return the choice."""
    while True:
        try:
            choice = int(input(f"Click 1 to fight the {get_random_monster()} or click 2 to run: "))
            if choice in [1, 2]:
                return choice
            else:
                print_pause("Invalid input.")
        except ValueError:
            print_pause("Please enter 1 or 2.")

def play_again():
    """Prompt the user to play again and return True if 'y', otherwise False."""
    while True:
        choice = input("Do you want to play again? (y/n): ").lower()
        if choice in ['y', 'n']:
            return choice == 'y'
        else:
            print_pause("Please enter 'y' or 'n'.")

# Story Functions
def lore0(entered_cave, current_monster_name):
    """Print the initial story and choices."""
    if not entered_cave:
        print_pause("You find yourself standing in an open field, filled with grass and yellow wildflowers.")
        print_pause(f"Rumor has it that a {current_monster_name} is somewhere around here and has been terrifying the nearby village.")
        print_pause("In front of you is a house.and you got informed that this house contains the fairy")
        print_pause("To your right is a dark cave. rumers says that this cave has a legendry weapon")


def lore1(magic_wand):
    """Print the story for entering the house."""
    print_pause("You have entered the house.")
    if magic_wand == 10:
        print_pause(f"You feel prepared and ready to face that {get_random_monster()}.")
    print_pause("You knock on the door (or in, I don't know).")
    print_pause(f"The house contains a {get_random_monster()}.")
    print_pause(f"The {get_random_monster()} saw you.")
    print_pause(f"The {get_random_monster()} runs after you.")
    return 3

def lore3():
    """Print the story for finding the magic wand in the cave and return its value."""
    print_pause("You have entered the cave.")
    print_pause("You find a GOOD MAGIC WAND WHICH DISAPPEARED 3000 YEARS AGO.")
    print_pause("You exchange it for the one you already have.")
    print_pause("You leave the cave for now.")
    return 10

# Main Game Loop
def main():
    """Run the main game loop."""
    while True:
        magic_wand = 0
        entered_cave = False
        current_monster_name = get_random_monster()

        while True:
            lore0(entered_cave, current_monster_name)
            choice = get_choice()

            if choice == 1:
                lore1(magic_wand)
                action = fight_or_run()
                if action == 1:
                    print_pause(f"You chose to fight the {current_monster_name}.")
                    if magic_wand == 10:
                        print_pause(f"You killed the {current_monster_name}. Congratulations!")
                        break
                    else:
                        print_pause(f"The {current_monster_name} killed you. Game over.")
                        break
                elif action == 2:
                    print_pause("You chose to run away!")
                    print_pause("You came back to the starting point.")
            elif choice == 2:
                if entered_cave:
                    print_pause("Nothing here. You return to the field.")
                else:
                    magic_wand = lore3()
                    entered_cave = True

            # Reevaluate monster after every action
            current_monster_name = get_random_monster()

        if not play_again():
            print_pause("Thank you for playing! Goodbye.")
            break

if __name__ == "__main__":
    main()
